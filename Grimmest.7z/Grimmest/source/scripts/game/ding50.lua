gd.ding50 = {}

local gd.ding50.tagpass = "tagDing50Worked"
local gd.ding50.tagfail = "tagDing50Failed"

function gd.ding50.xp4lvl( x )
	-- function to return the approx xp for a given level. taken from creatures/pc/playerlevels.dbr
	local rv = ((((( x * x * x ) ^ 1.16 ) * 32 ) + ( ( x * x ) * 300 ) ) * 0.1 ) + 38 
	return rv
end
function gd.ding50.onPickUp( looterId, objectId )
	-- this works, but xp does not seem accurate likely due to fact that we
	-- are not actually getting player xp, just the xp needed for the current level...
	-- the potion only works for the given levels, but you can still waste money on it
	-- at least update the tags to explain better what this does
	local player = Player.Get( looterId )
	local currentLevel = player:GetLevel()
	local currentXp = gd.ding50.xp4lvl( currentLevel )
	local level50xp = gd.ding50.xp4lvl( 50 )
	local xpneeded = math.floor( level50xp - currentXp )

	if currentLevel >= 45 && currentLevel < 50 then
		UI.Notify( string.format( "%s %d XP", gd.ding50.tagpass, xpneeded ) )
		player:GiveExperience( xpneeded )
	else
		UI.Notify( gd.ding50.tagfail );
	end
end
